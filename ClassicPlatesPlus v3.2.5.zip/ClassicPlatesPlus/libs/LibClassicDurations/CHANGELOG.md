# LibClassicDurations

## [1.69a](https://github.com/rgd87/LibClassicDurations/tree/1.69a) (2021-04-23)
[Full Changelog](https://github.com/rgd87/LibClassicDurations/compare/1.69...1.69a) [Previous Releases](https://github.com/rgd87/LibClassicDurations/releases)

- Added Chronoboon world buffs spell IDs  
